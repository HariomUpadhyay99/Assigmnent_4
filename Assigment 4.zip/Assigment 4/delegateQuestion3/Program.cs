﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace delegateQuestion3
{
    internal class Program
    {
        delegate void MyDelegate();

        static void Method1()
        {
            Console.WriteLine("Method 1 is called");
        }

        static void Method2()
        {
            Console.WriteLine("Method 2 is called");
        }

        static void Method3()
        {
            Console.WriteLine("Method 3 is called");
        }
    
    }
}
