﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace @delegate
{
    internal class Program
    {
        delegate void MyDelegate(int a, int b);

        static void Add(int a, int b)
        {
            Console.WriteLine("Sum = " + (a + b));
        }
        static void Main(string[] args)
        {
            // UNICAST
            Console.WriteLine("Unicast Delegate:");

            MyDelegate d1 = Method1;

            d1();


            // MULTICAST
            Console.WriteLine("\nMulticast Delegate:");

            MyDelegate d2 = Method1;

            d2 += Method2;
            d2 += Method3;

            d2();
        }
    }
}
