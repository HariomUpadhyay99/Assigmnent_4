﻿using System;

namespace delegate_Questions
{
    internal class delegateQuestion3
    {

        delegate void MyDelegate();

        static void Method1()
        {
            Console.WriteLine("Method 1 is called");
        }

        static void Method2()
        {
            Console.WriteLine("Method 2 is called");
        }

        static void Method3()
        {
            Console.WriteLine("Method 3 is called");
        }

        static void Main2()
        {
            // Unicast
            Console.WriteLine("Unicast Delegate:");

            MyDelegate d1 = Method1;

            d1();


            // Multicast
            Console.WriteLine("\nMulticast Delegate:");

            MyDelegate d2 = Method1;

            d2 += Method2;
            d2 += Method3;

            d2();
        }
}
    }
