﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace delegate_Questions
{
    internal class delegateQuestion9
    {
        static int Add(int a, int b)
        {
            return a + b;
        }

        static int Multiply(int a, int b)
        {
            return a * b;
        }

        static int Subtract(int a, int b)
        {
            return a - b;
        }

        static void Main8()
        {

            Func<int, int, int> f = Add;

            f += Multiply;
            f += Subtract;

            Console.WriteLine("Multicast Func Results:");


            foreach (Func<int, int, int> method in f.GetInvocationList())
            {
                int result = method(10, 20);

                Console.WriteLine(
                    method.Method.Name + " = " + result
                );
            }
        }
    }
}
