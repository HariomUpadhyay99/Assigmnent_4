﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace delegate_Questions
{
    internal class delegateQuestion1
    {
        delegate void MyDelegate(int a, int b);

        static void Add(int a, int b)
        {
            Console.WriteLine("Sum = " + (a + b));
        }

        static void Main()
        {
            MyDelegate d = Add;

            d(5, 10);
        }
    }
}

