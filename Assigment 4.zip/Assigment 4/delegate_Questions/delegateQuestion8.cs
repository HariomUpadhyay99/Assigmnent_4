﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace delegate_Questions
{
    internal class delegateQuestion8
    {
        static void Hello()
        {
            Console.WriteLine("Hello");
        }

        static void Welcome()
        {
            Console.WriteLine("Welcome");
        }

        static void Bye()
        {
            Console.WriteLine("Good Bye");
        }

        static void Main7()
        {
            Console.WriteLine("Unicast Action:");

            Action a1 = Hello;

            a1();

            Console.WriteLine("\nMulticast Action:");

            Action a2 = Hello;

            a2 += Welcome;
            a2 += Bye;

            a2();
        }
    }
}

