﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace delegate_Questions
{
    internal class delegateQuestion7
    {
        delegate void MyDelegate();

        static void first()
        {
            Console.WriteLine("Method 1 is executed");
        }

        static void second()
        {
            Console.WriteLine("Method 2 is executed");
        }

        static void third()
        {
            Console.WriteLine("Method 3 is executed");
        }

        static void Main6()
        {
            MyDelegate d;
            d = first;

            d += second;
            d += third;

            foreach (MyDelegate method in d.GetInvocationList())
            {
                Console.WriteLine("Method Name: " + method.Method.Name);

                method();

                Console.WriteLine();
            }
        }
    }
}
