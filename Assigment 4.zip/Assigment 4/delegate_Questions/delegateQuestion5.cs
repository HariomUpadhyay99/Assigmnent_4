﻿using System;


namespace delegate_Questions
{
    internal class delegateQuestion5
    {
        delegate void NotifyDelegate(string message);

        static void SendEmail(string message)
        {
            Console.WriteLine("Email: " + message);
        }

        static void SendSMS(string message)
        {
            Console.WriteLine("SMS: " + message);
        }

        static void SendWhatsApp(string message)
        {
            Console.WriteLine("WhatsApp: " + message);
        }

        static void Main4()
        {
            NotifyDelegate notify;
            notify = SendEmail;

            notify += SendSMS;
            notify += SendWhatsApp;

            notify("Your order has been shipped.");
        }
    }
}
