﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace delegate_Questions
{
    internal class delegateQuestion4
    {
        delegate double Calculator(double a, double b);

        static double Add(double a, double b)
        {
            return a + b;
        }

        static double Subtract(double a, double b)
        {
            return a - b;
        }

        static double Multiply(double a, double b)
        {
            return a * b;
        }

        static double Divide(double a, double b)
        {
            return a / b;
        }

        static void Main3()
        {
            Calculator c;

            c = Add;
            Console.WriteLine("Addition = " + c(20, 10));

            c = Subtract;
            Console.WriteLine("Subtraction = " + c(20, 10));

            c = Multiply;
            Console.WriteLine("Multiplication = " + c(20, 10));

            c = Divide;
            Console.WriteLine("Division = " + c(20, 10));
        }
    }
}
