﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace delegate_Questions
{
    internal class delegateQuestion10
    {
        static bool IsEven(int number)
        {
            return number % 2 == 0;
        }

        static bool IsPositive(int number)
        {
            return number > 0;
        }

        static bool IsGreaterThan100(int number)
        {
            return number > 100;
        }

        static void Main9()
        {
            int number = 120;

            Predicate<int> check = IsEven;

            check += IsPositive;
            check += IsGreaterThan100;

            Console.WriteLine("Checking number: " + number);
            Console.WriteLine();

            foreach (Predicate<int> method in check.GetInvocationList())
            {
                bool result = method(number);

                Console.WriteLine(
                    method.Method.Name + " = " + result
                );
            }
        }
    }
}
