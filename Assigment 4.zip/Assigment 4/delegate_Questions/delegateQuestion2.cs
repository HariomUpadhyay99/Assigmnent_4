﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace delegate_Questions
{
    internal class delegateQuestion2
    {
        delegate int sumTwoNum(int x, int y);

        static int add(int x, int y)
        {
            return x + y;
        }
        static void Main1(string[] args)
        {
            sumTwoNum sum = add;

            int res = sum(10, 20);
            Console.WriteLine("Sum of two numbers: " + res);
        }

    }
}
